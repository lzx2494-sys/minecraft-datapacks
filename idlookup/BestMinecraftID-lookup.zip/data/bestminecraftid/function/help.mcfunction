tellraw @s [{"text":"===== BestMinecraftID =====","color":"gold"}]
tellraw @s [{"text":"Item: ","color":"gray"},{"text":"/function bestminecraftid:id/<item_name>","color":"green"}]
tellraw @s [{"text":"Entity: ","color":"gray"},{"text":"/function bestminecraftid:entity/<entity_name>","color":"green"}]
tellraw @s [{"text":"ID catalog + command generators: ","color":"gray"},{"text":"bestminecraftid.com","color":"aqua","underlined":true,"click_event":{"action":"open_url","url":"https://bestminecraftid.com"}}]
